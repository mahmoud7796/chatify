<div class="row">
    <div class="col-lg-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr>
                        <th class="text-right">اسم الطالب</th>
                        <th class="text-right">تاريخ التقديم</th>
                        <th class="text-right">الحل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd">
                            <td><?php echo e($answer->student->user->name); ?></td>
                            <td><i class="fa fa-calendar"></i> <?php echo e($answer->created_at->format('d-m-Y')); ?></td>
                            <td><a href="<?php echo e(asset("/storage/$answer->answer")); ?>" target="_blank"><img
                                        src="<?php echo e(asset("/storage/$answer->answer")); ?>"
                                        alt="homework<?php echo e($answer->student->user->name); ?>" width="150px"></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH /home/chilpyse/public_html/cms/cpanel/resources/views/pages/teacher/answer/table.blade.php ENDPATH**/ ?>