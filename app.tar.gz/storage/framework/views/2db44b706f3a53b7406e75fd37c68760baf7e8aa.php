<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">الواجبات
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    الواجبات
                    <?php if(isset($grade)): ?>
                        - للصف <b><?php echo e($grade->name); ?></b>
                    <?php endif; ?>
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th class="text-right">العنوان</th>
                                    <th class="text-right">الايضاح</th>
                                    <th class="text-right">المعلمة</th>
                                    <th class="text-right">الصف</th>
                                    <th class="text-right">التاريخ</th>
                                    <th class="text-right">ردود الطلاب</th>
                                    <th class="text-right">#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $homeworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="odd">
                                        <td><?php echo e($homework->subject); ?></td>
                                        <td><?php echo e($homework->content); ?></td>
                                        <td><?php echo e($homework->teacher->user->name); ?></td>
                                        <td><?php echo e($homework->grade->name); ?></td>
                                        <td><i class="fa fa-calendar"></i> <?php echo e($homework->created_at->format('d-m-Y')); ?></td>
                                        <td><a href="<?php echo e(route('teacher.homework.answer', $homework)); ?>">عرض إجابات
                                                (<?php echo e($homework->answers_count); ?>)
                                                طالب قام بالحل</a>
                                        </td>
                                        <td style="width: 260px">
                                            <form action="<?php echo e(route('teacher.homework.destroy', $homework)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <p>
                                                    <button class="btn btn-sm btn-social btn-danger deleteBtn"
                                                        type="button">
                                                        <i class="fa fa-times"></i> حذف
                                                    </button>
                                                    
                                                    <a class="btn btn-sm btn-social btn-primary"
                                                        href="<?php echo e(route('teacher.homework.show', $homework)); ?>">
                                                        <i class="fa fa-eye"></i> عرض
                                                    </a>
                                                </p>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4">
                                        يتم عرض عدد (<?php echo e($homeworks->count()); ?>) واجب من إجمالي (<?php echo e($homeworks->total()); ?>)
                                        واجبات
                                    </td>
                                    <td colspan="3" class=" text-left">
                                        <?php echo e($homeworks->links()); ?>

                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        window.addEventListener('load', function() {
            $('.deleteBtn').on('click', function(e) {
                var ok = confirm('هل أنت متأكد من حذف السجل؟');
                if (ok) {
                    $(this).parents('form').submit();
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/chilpyse/public_html/cms/cpanel/resources/views/pages/teacher/homework/index.blade.php ENDPATH**/ ?>