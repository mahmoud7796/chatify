<!doctype html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'روضة عالم الاطفال')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<?php echo \Livewire\Livewire::styles(); ?>

<body>
    <div id="wrapper">
        <?php $prefix = Auth::user()->role_key; ?>
        <?php echo $__env->make("pages.{$prefix}.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main>
            <div id="page-wrapper">
                <div class="container-fluid">

                    <?php if(session()->has('message')): ?>
                        <div class="row" style="margin-top: 20px">
                            <div class="col-12">
                                <div class="alert alert-<?php echo e(session()->get('message.type')); ?> alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert"
                                        aria-hidden="true">×</button>
                                    <?php echo e(session()->get('message.text')); ?></a>.
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </main>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH /home/chilpyse/public_html/cms/cpanel/resources/views/layouts/app.blade.php ENDPATH**/ ?>