<?php return array (
  'chat' => 'App\\Http\\Livewire\\Chat',
);