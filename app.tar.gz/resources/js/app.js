require('./bootstrap');
require('./bootstrap.min');
require('./metisMenu.min');
require('./startmin');